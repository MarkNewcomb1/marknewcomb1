<?php
	
abstract class MySQL_interface{
	
	protected function MySQL_connect(){
		$db_dsn="mysql:dbname=forecastMySQL";
		$db_username="root";
		$db_password="~Rushmore1998";
		try{
			$connection=new PDO($db_dsn,$db_username,$db_password);
			$connection->setAttribute(PDO::ATTR_PERSISTENT,true);
			$connection->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
			return $connection;
		}
		catch(PDOException $e){
			die("connection failed: ".$e->getMessage());
		}	
	}

	abstract protected function build_MySQL_statement($params);
	
	public static function purge($input){
		$input=gettype($input)!='array' ? htmlspecialchars($input, ENT_QUOTES) : $input;
		//$input=str_replace(",", "&#44;", $input);
		//$input=str_replace("'",'&#39;',$input);
		return $input;
	}
	
	public static function binge($input){
		$input=gettype($input)!='array' ? htmlspecialchars_decode($input, ENT_QUOTES) : $input;
		//$input=str_replace("&#44;",",", $input);
		//$input=str_replace("&#39;","'",$input);
		return $input;
	}
}
	
?>
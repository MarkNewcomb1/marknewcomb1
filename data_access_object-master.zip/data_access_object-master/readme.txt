9c35f52fffb4e7b6c1a1743864a92121ca83ccc5

plugin name: Data Access Object
plugin handle: data_access_object
plugin version: v2.1